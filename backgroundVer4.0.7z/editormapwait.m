function editormapwait
h=figure;
%uiwait(h)
colormapeditor
%uiresume(h)
disp('done');
